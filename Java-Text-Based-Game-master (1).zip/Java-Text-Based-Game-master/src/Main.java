
public class Main {

    public static void main(String[] args) {
        GameSetUp newGame = new GameSetUp();
        newGame.GameSetUp();
    }
}
